﻿using System;
using System.Configuration;
using System.IO;
using TWI.Utils.SocialMedia.Twitter;
using TWI.Utils.SocialMedia.Twitter.Models;

namespace TWI.Utils.TestConsole
{
    class Program
    {
        public static string ConsumerKey = ConfigurationManager.AppSettings["ConsumerKey"];
        public static string ConsumerSecret = ConfigurationManager.AppSettings["ConsumerSecret"];
        public static string AccessToken = ConfigurationManager.AppSettings["AccessToken"];
        public static string AccessTokenSecret = ConfigurationManager.AppSettings["AccessTokenSecret"];

        
        static void Main(string[] args)
        {
            var twitter = new TwitterHelper();
            var tweets = twitter.GetUserTimeline();
            foreach(var tweet in tweets)
            {
                Console.WriteLine(tweet.Text);
            }
            Console.WriteLine();
            Console.ReadKey();
        }
    }
}
